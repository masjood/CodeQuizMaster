package com.codequizmaster.controller;

import com.codequizmaster.entity.ContactMessage;
import com.codequizmaster.service.ContactMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ContactController {

    @Autowired
    private ContactMessageService contactMessageService;

    @PostMapping("/contact")
    public String handleContactSubmission(@RequestParam String name, @RequestParam String email, @RequestParam String message, Model model) {
        ContactMessage contactMessage = new ContactMessage();
        contactMessage.setName(name);
        contactMessage.setEmail(email);
        contactMessage.setMessage(message);
        contactMessageService.save(contactMessage);
        model.addAttribute("successMessage", "Thank you for your message! We will get back to you soon.");
        return "contact-us";
    }
}
