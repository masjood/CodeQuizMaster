package org.example.quizmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
