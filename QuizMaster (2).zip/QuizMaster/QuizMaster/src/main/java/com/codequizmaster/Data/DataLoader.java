package com.codequizmaster.Data;

import com.codequizmaster.entity.Role;
import com.codequizmaster.entity.User;
import com.codequizmaster.service.RoleService;
import com.codequizmaster.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class DataLoader implements CommandLineRunner {
    private final UserService userService;
    private final RoleService roleService;
    private final PasswordEncoder passwordEncoder;

    public DataLoader(UserService userService, RoleService roleService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        if (userService.findAll().isEmpty()) {
            Role userRole = new Role();
            userRole.setName("ROLE_USER");
            roleService.save(userRole);

            Role adminRole = new Role();
            adminRole.setName("ROLE_ADMIN");
            roleService.save(adminRole);

            Set<Role> userRoles = new HashSet<>();
            userRoles.add(userRole);

            Set<Role> adminRoles = new HashSet<>();
            adminRoles.add(adminRole);

            User user1 = new User();
            user1.setUsername("user1");
            user1.setPassword(passwordEncoder.encode("user1"));
            user1.setEmail("user1@example.com");
            user1.setRoles(userRoles);
            userService.save(user1);

            User user2 = new User();
            user2.setUsername("admin");
            user2.setPassword(passwordEncoder.encode("admin"));
            user2.setEmail("admin@example.com");
            user2.setRoles(adminRoles);
            userService.save(user2);
        }
    }
}
