document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup);
    }
});

function handleSignup(event) {
    event.preventDefault();

    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const confirmPassword = document.getElementById('confirm-password').value.trim();

    if (!username || !email || !password || !confirmPassword) {
        showMessage('error', 'All fields are required.');
        return;
    }

    if (!validateEmail(email)) {
        showMessage('error', 'Invalid email format. Please enter a valid email address.');
        return;
    }

    if (!validatePassword(password)) {
        showMessage('error', 'Password must be at least 8 characters long, include at least one uppercase letter, and one number.');
        return;
    }

    if (password !== confirmPassword) {
        showMessage('error', 'Passwords do not match.');
        return;
    }

    const data = {
        username: username,
        email: email,
        password: password,
        confirmPassword: confirmPassword
    };

    sendPostRequest('/api/signup', data, (error, response) => {
        if (error) {
            showMessage('error', 'Signup failed. Please try again.');
            console.error('Signup error:', error);
            return;
        }

        if (response.error) {
            showMessage('error', response.error);
            return;
        }

        // On successful signup, redirect to login page
        navigateToPage('/login');
    });
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email.toLowerCase());
}

function validatePassword(password) {
    const re = /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/;
    return re.test(password);
}

function showMessage(type, message) {
    const messageContainer = document.getElementById('error-message');
    if (messageContainer) {
        messageContainer.style.display = 'block';
        messageContainer.textContent = message;
    }
    console.log(type, message); // For now, just log it
}

// function sendPostRequest(url, data, callback) {
//     fetch(url, {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify(data)
//     })
//         .then(response => {
//             if (!response.ok) {
//                 return response.json().then(err => { throw err; });
//             }
//             return response.json();
//         })
//         .then(data => callback(null, data))
//         .catch(error => callback(error, null));
// }
function sendPostRequest(url, data, callback) {
    console.log("sending post request:", url);
    // Get the CSRF token from the hidden input field in the form
    const csrfToken = document.querySelector('input[name="_csrf"]').value;

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            // Include the CSRF token in the request headers
            'X-CSRF-TOKEN': csrfToken
        },
        body: JSON.stringify(data)
    })
        .then(response => {
            // Check if the response is JSON
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return response.json();
            } else {
                // If not JSON, handle other types of responses
                return response.text().then(text => {
                    throw new Error(text);
                });
            }
        })
        .then(data => {
            console.log('response:', data);
            callback(null, data);
        })
        .catch(error => {
            console.error('error from function', error);
            callback(error, null);
        })
}


function navigateToPage(page) {
    window.location.href = page; // Assuming your routes match this format
}
