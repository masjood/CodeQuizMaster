package com.codequizmaster.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    // Home page
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // About us page
    @GetMapping("/about-us")
    public String aboutUsPage() {
        return "about-us";
    }

    // Resources page
    @GetMapping("/resources")
    public String resourcesPage() {
        return "resources";
    }

    // Contact us page
    @GetMapping("/contact")
    public String contactPage() {
        return "contact-us";
    }
}
