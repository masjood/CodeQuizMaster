document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
});

function handleLogin(event) {
    event.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        showMessage('error', 'Please enter both username and password.');
        return;
    }

    const data = {
        username: username,
        password: password
    };

    sendPostRequest('/api/login', data, (error, response) => {
        if (error) {
            showMessage('error', 'Login failed. Please try again.');
            console.error('Login error:', error);
            return;
        }

        if (response.error) {
            showMessage('error', response.error);
            return;
        }

        localStorage.setItem('currentUser', JSON.stringify(response.user));

        // Redirect to the homepage
        navigateToPage('/');
    });
}

function showMessage(type, message) {
    const messageContainer = document.getElementById('error-message');
    if (messageContainer) {
        messageContainer.style.display = 'block';
        messageContainer.textContent = message;
    }
    console.log(type, message); // For now, just log it
}

function sendPostRequest(url, data, callback) {
    const csrfToken = document.querySelector('meta[name="_csrf"]').getAttribute('content');
    const csrfHeader = document.querySelector('meta[name="_csrf_header"]').getAttribute('content');

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            [csrfHeader]: csrfToken
        },
        body: JSON.stringify(data)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => callback(null, data))
        .catch(error => {
            console.error('Fetch error:', error);
            callback(error, null);
        });
}


function navigateToPage(page) {
    window.location.href = page; // Assuming your routes match this format
}
