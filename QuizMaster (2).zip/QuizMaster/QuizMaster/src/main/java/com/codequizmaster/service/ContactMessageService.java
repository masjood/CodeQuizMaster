package com.codequizmaster.service;

import com.codequizmaster.entity.ContactMessage;
import com.codequizmaster.repository.ContactMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactMessageService {

    @Autowired
    private ContactMessageRepository contactMessageRepository;

    public ContactMessage save(ContactMessage contactMessage) {
        return contactMessageRepository.save(contactMessage);
    }

    public List<ContactMessage> findAll() {
        return contactMessageRepository.findAll();
    }

    public ContactMessage findById(Long id) {
        return contactMessageRepository.findById(id).orElse(null);
    }

    public void deleteContactMessage(Long id) {
        contactMessageRepository.deleteById(id);
    }
}
