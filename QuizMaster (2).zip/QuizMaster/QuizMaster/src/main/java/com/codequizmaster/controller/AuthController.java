package com.codequizmaster.controller;

import com.codequizmaster.entity.User;
import com.codequizmaster.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Controller
public class AuthController {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public AuthController(UserService userService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    // User registration page
    @GetMapping("/signup")
    public String signupPage() {
        return "signup";
    }

    @PostMapping("/signup")
    public String registerUser(@RequestParam String username, @RequestParam String email, @RequestParam String password, @RequestParam String confirmPassword, Model model) {

        if (!password.equals(confirmPassword)) {
            model.addAttribute("errorMessage", "Passwords do not match");
            return "signup";
        }
        if (userService.findByUsername(username).isPresent()) {
            model.addAttribute("errorMessage", "Username already taken");
            return "signup";
        }
        if (userService.findByEmail(email).isPresent()) {
            model.addAttribute("errorMessage", "Email already taken");
            return "signup";
        }
        try {
            User user = new User();
            user.setUsername(username);
            user.setEmail(email);
            user.setPassword(passwordEncoder.encode(password)); // Correctly encode password before saving
            userService.save(user);
            return "redirect:/login";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "An error occurred during registration. Please try again.");
            return "signup";
        }
    }

    // Login page
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // RESTful endpoint for user registration
    @PostMapping("/api/signup")
    @ResponseBody
    public Map<String, String> apiRegisterUser(@RequestBody Map<String, String> payload) {
        Map<String, String> response = new HashMap<>();
        String username = payload.get("username");
        String email = payload.get("email");
        String password = payload.get("password");
        String confirmPassword = payload.get("confirmPassword");

        if (!password.equals(confirmPassword)) {
            response.put("error", "Passwords do not match");
            return response;
        }
        if (userService.findByUsername(username).isPresent()) {
            response.put("error", "Username already taken");
            return response;
        }
        if (userService.findByEmail(email).isPresent()) {
            response.put("error", "Email already taken");
            return response;
        }
        try {
            User user = new User();
            user.setUsername(username);
            user.setEmail(email);
            user.setPassword(passwordEncoder.encode(password)); // Correctly encode password before saving
            userService.save(user);
            response.put("message", "User registered successfully");
        } catch (Exception e) {
            e.printStackTrace();
            response.put("error", "An error occurred during registration. Please try again.");
        }
        return response;
    }

    // RESTful endpoint for user login
    @PostMapping("/api/login")
    @ResponseBody
    public Map<String, String> apiLoginUser(@RequestBody Map<String, String> payload) {
        Map<String, String> response = new HashMap<>();
        String username = payload.get("username");
        String password = payload.get("password");

        try {
            Optional<User> userOptional = userService.findByUsername(username);
            if (userOptional.isPresent()) {
                User user = userOptional.get();
                if (passwordEncoder.matches(password, user.getPassword())) { // Ensure the password is correctly matched
                    response.put("message", "Login successful");
                    response.put("user", user.getUsername()); // Add other user details if needed
                } else {
                    response.put("error", "Invalid password");
                }
            } else {
                response.put("error", "User not found");
            }
        } catch (Exception e) {
            response.put("error", "An error occurred during login. Please try again.");
        }
        return response;
    }
}
