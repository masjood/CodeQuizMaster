package com.codequizmaster.controller;

import com.codequizmaster.entity.Question;
import com.codequizmaster.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@Controller
public class QuizController {

    @Autowired
    private QuestionService questionService;

    // Quiz pages
    @GetMapping("/quiz/{language}")
    public String quizPage(@PathVariable String language, Model model) {
        List<Question> questions = questionService.findAll(); // Assuming you filter questions by language somehow
        model.addAttribute("questions", questions);
        model.addAttribute("language", language);
        return language + "-quiz"; // Ensures the correct template is used
    }

    @PostMapping("/quiz/{language}/submit")
    public String submitQuiz(@PathVariable String language, @RequestParam List<Long> questionIds, @RequestParam List<Integer> answers, Model model) {
        // Logic to evaluate quiz and calculate score
        int score = 0;
        for (int i = 0; i < questionIds.size(); i++) {
            Optional<Question> question = Optional.ofNullable(questionService.findById(questionIds.get(i)));
            if (question.isPresent() && question.get().getCorrectOptionIndex() == answers.get(i)) {
                score++;
            }
        }
        model.addAttribute("score", score);
        return "results";
    }

    // Results page
    @GetMapping("/results")
    public String resultsPage() {
        return "results";
    }
}
